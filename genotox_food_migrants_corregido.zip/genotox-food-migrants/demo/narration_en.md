# Optional English narration — two-minute revised demo

No audio was generated. Record this yourself if you want a voice-over; use the times as scene cues and leave pauses for the visual changes.

**00:00–00:08**
Would you trust a tiny model score? First, inspect the chemistry behind the number.

**00:08–00:18**
This published candy-wrapper study supplies the chemical case: thirty-three curated assignments, twenty-two marked standard-confirmed. Our model calculations are separate from the study's findings.

**00:18–00:30**
The tentative Irganox degradation product triggers our Michael-acceptor motif rule. Its classifier score is small, but its nearest training similarity is only zero point two zero three. Neither result establishes safety.

**00:30–00:42**
The inspector connects the assigned molecular structure to its nearest EFSA training neighbour. At our selected zero point four cutoff, this structure's score is excluded from the aggregate.

**00:42–01:05**
Explore twenty retained structures with the same formula. Click a molecule, and marimo updates its drawing, nearest neighbour, score and structural motifs. These are hypothetical alternatives for sensitivity analysis, without supporting peak spectra. Enumeration order is not an identification ranking.

**01:05–01:15**
Compare structures fourteen and fifteen. The formula is identical, but connectivity differs. One matches the Michael-acceptor rule; the other has no match in our partial ten-rule set.

**01:15–01:28**
Under equal weights, six structures pass the zero point four criterion: thirty percent coverage. The conditional score describes only that included subset. Seventy percent of the hypothetical identity weight remains excluded.

**01:28–01:40**
Raise the cutoff to zero point six. Coverage reaches zero and the aggregate score becomes unavailable. Marimo updates downstream results without retraining. The cutoff remains an exploratory rule.

**01:40–01:50**
The full project tests baselines across five scaffold splits, diagnoses calibration and audits identity uncertainty. These are internal evaluations; the raw demo score remains uncalibrated.

**01:50–02:00**
The useful result guides follow-up: confirm the tentative identity, report covered identity weight, and use experimental evidence for hazard assessment. Show the uncertainty. Choose the next experiment.
