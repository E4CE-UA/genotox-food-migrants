# Notebook completo y demo revisada

Para sustituir tu demo actual:

1. Conserva una copia de tu archivo anterior.
2. Sustituye `notebooks/what_if_wrong_compound.py` por el archivo completo entregado.
3. Ábrelo como antes: `marimo edit notebooks/what_if_wrong_compound.py`.

La demo incluye los mismos controles químicos corregidos dentro del propio archivo como compatibilidad con la versión anterior de tu paquete. Se ha comprobado ese caso: 1.892 identidades de entrenamiento, 130 etiquetas positivas y la misma cobertura del vídeo. No tienes que pegar fragmentos de código.

Para aplicar las correcciones también al análisis completo, usa esta carpeta del proyecto o copia los módulos `src/chemistry.py`, `src/labels.py`, `src/external.py`, `src/provenance.py`, `src/ttc.py`, los tres notebooks y `requirements.txt` a tu repositorio. Los datos originales están incluidos. Las cachés anteriores se invalidan cuando no coinciden la política química y la versión de RDKit.

```bash
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/marimo edit notebooks/what_if_wrong_compound.py
```

## Qué se corrigió

- Las sales metálicas y entradas con varias especies que contienen carbono se excluyen antes de eliminar fragmentos. No se transfiere la etiqueta de un metal al citrato, sulfato, acetato o agua.
- Las conclusiones se reconcilian por identidad estandarizada y se vuelve a aplicar la regla de etiquetas; no decide la primera fila.
- Entrenamiento y candidatos usan la misma preparación molecular.
- La incorporación opcional de fuentes externas conserva la elegibilidad química y registra desacuerdos.
- Cero cobertura da una decisión no disponible, sin computarla como negativa.
- Se recalcularon figuras y métricas, y se actualizaron la narrativa y la procedencia.

## Vídeo

`marimo_demo_revised_2min.mp4` dura exactamente 120 segundos, 1920×1080, 30 fps, sin pista de audio. Texto en inglés. Incluye figuras moleculares de RDKit, interacción real de marimo y cifras de la versión corregida.

Caso principal: producto de degradación de Irganox 1010, FCM2018-0010. El score de la identidad asignada es ~0,000461 y su similitud al vecino más próximo es 0,203. Al explorar 20 estructuras de igual fórmula con pesos uniformes, la cobertura pasa del 30% al 0% al mover Tc de 0,40 a 0,60. Los pesos y el umbral son escenarios exploratorios, no confianza medida. Las alternativas no se han identificado con los espectros.

El guion inglés en `demo/narration_en.md` es opcional, por si decides grabar tu voz; no se ha generado audio.

## Verificación

Nueve pruebas químicas pasaron. El análisis completo se ejecutó con cinco semillas y los datos reales del bundle. Los tres notebooks pasaron `marimo check`. `docs/` contiene el registro, métricas, auditoría del caso y comprobación de compatibilidad.

La PR-AUC mediana de LightGBM fue 0,581 [0,486–0,591], frente a 0,480 [0,437–0,546] para regresión logística. Son evaluaciones internas por scaffold; no validación experimental externa ni prueba de inocuidad. El score de la demo permanece sin calibrar. Las estructuras acíclicas se agrupan individualmente y familias próximas pueden repartirse entre entrenamiento y test.

## Título recomendado para el formulario

Uncertainty-aware hazard screening for food-contact migrants — EFSA OpenFoodTox genotoxicity conclusions and FCM2018 candy-wrapper GC–MS assignments; marimo, RDKit and LightGBM — Wildcard track.

El estudio de 2018 respalda los datos de asignación; no publicó los scores de este proyecto. La versión concreta del export de OpenFoodTox todavía necesita su identificador/DOI.
