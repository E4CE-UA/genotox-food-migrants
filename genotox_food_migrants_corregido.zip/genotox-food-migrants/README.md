# Uncertainty-aware hazard screening for food-contact migrants

An interactive marimo workflow connecting EFSA OpenFoodTox genotoxicity conclusions to structures and explicit identity scenarios for GC–MS assignments. The competition demo asks **What if the chemical identity is wrong?**

The full analysis compares a majority baseline, logistic regression and LightGBM, evaluates held-out scores across scaffold splits, diagnoses calibration, audits identity evidence and propagates alternative structures through screening. Scores are uncalibrated classifier outputs; this project does not establish chemical safety or measured migration into food.

## Run

```bash
python3.12 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/marimo edit notebooks/what_if_wrong_compound.py
```

Bundled data support the default demo without fetching new studies. Use `notebooks/genotox_marimo.py` for the complete analysis and `notebooks/demo.py` for the earlier compact view.

```bash
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python -m marimo check notebooks/what_if_wrong_compound.py notebooks/genotox_marimo.py notebooks/demo.py
.venv/bin/python notebooks/genotox_marimo.py
```

The final command executes default controls, not every possible setting. Molab installs the repository package through the notebook's inline dependency declaration. The competition demo embeds the same audited identity guards as a compatibility fallback, so replacing this complete file also works with the earlier package. The full analysis uses the corrected modules in this repository.

## Chemical identity and labels

- An EFSA row is a substance–output conclusion, not an independent chemical.
- Raw identity aggregation remains for auditing. After standardization, original positive, negative and ambiguous conclusion counts are combined by standardized InChIKey and the selected label rule is reapplied. First-row deduplication never arbitrates labels.
- The representation is one carbon-containing parent with supported elements. Inorganic inputs, unsupported metals/complexes and multiple carbon-containing fragments are excluded **before** fragment removal. Isolated Na+ and K+ counterions are supported. Exclusion means outside model scope, not non-genotoxic.
- Training and candidate structures use the same scope check, RDKit cleanup, parent selection, uncharging and canonical tautomer preparation, followed by radius-2, 2,048-bit Morgan fingerprints. Cache rows record the policy and RDKit version; old entries cannot silently retain previous chemistry.
- Under `any_positive` and `ambiguous="exclude"`, the corrected bundled dataset gives **1,892 modelable parent identities, 130 positive**. It excludes 146 aggregated inputs and combines 34 groups of raw identities. The six conflicting keys in the earlier cleanup were caused by unsupported metal or mixture inputs; they no longer transfer labels onto citrate, sulfate, acetate, water or acrylamide.
- Ring-containing scaffolds stay on one side of each train/test split. Acyclic compounds each have their own group, so related acyclic series can span folds. Scaffold separation does not guarantee independent external validation.

## Corrected default run

The full notebook completed with five seeds (0–4), the real bundled FCM2018 table and no external endpoint merge. Values are medians [IQR] across held-out splits; this is internal evaluation, not a migration or genotoxicity assay.

| Model | PR-AUC | ROC-AUC | MCC at top-prevalence rank |
|---|---|---|---|
| Majority baseline | 0.098 [0.064–0.101] | 0.500 [0.500–0.500] | 0.057 [0.041–0.064] |
| Logistic regression | 0.480 [0.437–0.546] | 0.808 [0.753–0.866] | 0.398 [0.377–0.444] |
| LightGBM | 0.581 [0.486–0.591] | 0.881 [0.843–0.884] | 0.466 [0.398–0.491] |

The prevalence baseline varies across splits. ECE and reliability plots diagnose calibration; no probability calibration is fitted. The illustrative TTC section does not calculate exposure or regulatory compliance. Under current defaults it tightens none of the 33 feature limits. Zero evaluable identity weight produces an unavailable model decision, not an unchanged or negative verdict.

![Corrected default FCM2018 identity coverage and illustrative TTC chain.](decision_chain.png)

![Declared-ambiguity benchmark: sensitivity to candidate-set size and assumed ranking evidence.](identity_size.png)

## Competition case

**FCM2018-0010 — Irganox 1010 degradation product** is a tentative assignment in the curated candy-wrapper study. The assigned C17H24O3 structure is absent from the EFSA training identities. Its raw score is about 0.000461, closest training-fingerprint similarity 0.203, and the project's partial SMARTS list matches a Michael-acceptor motif. None establishes genotoxicity.

For 20 retained same-formula structures, equal weights give 30% included identity weight at Tc ≥ 0.40 and 0% at Tc ≥ 0.60. The latter gives no aggregate score. Weights and Tc values are exploratory controls, not calibrated identification confidence or validated reliability boundaries. Formulae come from assigned structures; alternatives are not supported by the peak's EI spectrum, retention index, volatility or migration plausibility. Enumeration order is not an evidence ranking. Standard-confirmed entries retain their assigned identity weight even when other structures are inspected.

## Layout and optional inputs

| Path | Role |
|---|---|
| `notebooks/what_if_wrong_compound.py` | Competition demo: assignments, molecular drawings, alerts, applicability, coverage and provenance export |
| `notebooks/genotox_marimo.py` | Complete analysis and controls |
| `src/data.py`, `labels.py`, `provenance.py`, `resolver.py` | EFSA acquisition, conclusions, reconciliation and source audits |
| `src/chemistry.py`, `splitting.py`, `models.py` | Representation, splits, models and calibration diagnostics |
| `src/public_features.py`, `candidates.py`, `gcms.py`, `integration.py` | Public assignments, retained structures and optional read-only candidate export |
| `src/ambiguity.py`, `ttc.py`, `candidate_view.py`, `figures.py` | Declared-ambiguity experiments, illustrative consequences and displays |
| `src/retention.py` | Retention-index tooling; the historical experiment narrated in section 13 is not rerun by default |
| `src/external.py` | Optional mutagenicity CSVs; conflicting external-only labels are reported and excluded |
| `src/legacy/` | Earlier exploratory scripts, not imported by current analysis |
| `tests/test_chemical_identities.py` | Regression checks for scope, standardized labels, caches, external sources and unavailable decisions |

A local `GCMS_DB` SQLite export or `data/gcms_candidates.parquet` can override the public bundle. SQLite opens read-only. Local evidence-to-weight conversion remains an explicit assumption. External CSVs in `data/external/` require `smiles,y,source` and can mix endpoints; they are unused by default.

The declared-ambiguity benchmark deliberately simulates candidate ranking quality. The public assignment branch uses real deposited/curated assignments and PubChem structures, with hypothetical uniform alternatives when evidence is unavailable. Chemprop/conformal prediction and MEGAN remain unimplemented.

## Sources and license

Code is MIT licensed. Source data retain their original terms.

| Bundled data | Source |
|---|---|
| `genotoxicity_cas_cid.xlsx`, `efsa_estructuras.csv` | EFSA OpenFoodTox substance–output conclusions joined to PubChem structures; EFSA columns CC BY 4.0. The export's release identifier/DOI still needs documentation. |
| `metabolights/FCM2018__*.tsv` | Tables 2–3 of Galmán Graíño et al. (2018), *GC-MS Screening Analysis for the Identification of Potential Migrants in Plastic and Paper-Based Candy Wrappers*, Polymers 10(7), 802, [doi:10.3390/polym10070802](https://doi.org/10.3390/polym10070802), CC BY 4.0. FCM2018 identifiers are local project labels. |
| Other `metabolights/*.tsv` and public bundles | MetaboLights assignments for MTBLS1866, MTBLS627, MTBLS522, MTBLS8966, MTBLS519, MTBLS4497 and MTBLS892; cite each study and its recorded terms. Retained same-formula structures are PubChem data. |

The demo reproduces Figure 1 of the candy-wrapper paper, © 2018 the authors, CC BY 4.0, with attribution and display controls. Its pixels do not produce model scores. The provenance download includes hashes, identifiers, versions and control settings. Project calculations are not an EFSA position.

AI assistance was used for code review, chemical-input guards, regression tests, documentation and presentation text. Molecular drawings and numeric results are generated from recorded structures and notebook calculations.
